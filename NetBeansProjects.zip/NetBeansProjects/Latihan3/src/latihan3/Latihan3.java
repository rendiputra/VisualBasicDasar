/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan3;

/**
 *
 * @author Win10
 */
public class Latihan3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int panjang,lebar,hasil; 
        panjang = 10;
        lebar = 5;
        hasil = panjang*lebar;
        System.out.println("Cara Menghitung Luas Persegi ");
        System.out.println("Panjang  : 10");
        System.out.println("Lebar    : 5");
        System.out.println("Hasil    : "+hasil);
        
    }
    
}
