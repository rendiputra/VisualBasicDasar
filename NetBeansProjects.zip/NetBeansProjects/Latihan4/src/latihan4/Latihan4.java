/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan4;

/**
 *
 * @author Win10
 */
public class Latihan4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double alas,tinggi,hasil; 
        alas = 10;
        tinggi = 5;
        hasil = alas*tinggi*0.5;
        System.out.println("Cara Menghitung Luas Persegi ");
        System.out.println("Alas   : 10");
        System.out.println("Tinggbhjgf : 5");
        System.out.println("Hasil  : "+hasil);
        
    }
    
}
