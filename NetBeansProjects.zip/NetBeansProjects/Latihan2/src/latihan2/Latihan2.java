/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan2;

/**
 *
 * @author Win10
 */
public class Latihan2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nama,alamat,hobi,kelas; 
        int usia; 
        double tinggi;
        
        nama = "ABC";
        alamat = "Bekasi, Tambun ";
        hobi = "Renang";
        kelas = "XI RPL 1";
        usia = 16;
        tinggi = 150.5;
        System.out.println("Nama   : "+nama);
        System.out.println("Usia   : "+usia);
        System.out.println("Tinggi : "+tinggi);
        System.out.println("Alamat : "+alamat);
        System.out.println("Hobi   : "+hobi);
        System.out.println("Kelas  : "+kelas);
        
    }
    
}
