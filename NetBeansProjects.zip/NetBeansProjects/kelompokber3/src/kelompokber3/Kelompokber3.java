/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kelompokber3;

/**
 *
 * @author Win10
 */
public class Kelompokber3 {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /* XII RPL 1
        * Rendi Putra Pradana
        * M Hanif
        * Rio M
        */
        double sisi,hasil1, alas , tinggi, hasil2 ,hasil3, phi ,r; 
        sisi = 5;
        hasil1 = sisi * sisi;
        System.out.println("Cara Menghitung Luas Persegi ");
        System.out.println("Sisi   : 5");
        System.out.println("Hasil  : "+hasil1);
        System.out.println("--------------------------------------------------");
        // --------------------------------------------------
        alas = 10 ;
        tinggi = 5 ;
        hasil2 = alas * tinggi * 0.5;
        System.out.println("Cara Menghitung Segitiga ");
        System.out.println("Alas   : 10");
        System.out.println("Tinggi : 5");
        System.out.println("Hasil  : "+hasil2);
        System.out.println("--------------------------------------------------");
        // --------------------------------------------------
        phi = 3.14;
        r = 14;
        hasil3 = phi * r * r;
        System.out.println("Cara Menghitung Lingkaran ");
        System.out.println("Jari - Jari : 14");
        System.out.println("Hasil  : "+hasil3);        
    }
    
}
